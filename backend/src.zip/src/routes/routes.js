const express = require('express');
const router = express.Router();

// Controllers únicos
const ctrl = require('../controllers/controller');

// ========== ALUNOS ==========
router.get('/alunos', ctrl.alunosListar);
router.get('/alunos/:id', ctrl.alunosBuscar);
router.post('/alunos', ctrl.alunosCriar);
router.put('/alunos/:id', ctrl.alunosAtualizar);
router.delete('/alunos/:id', ctrl.alunosDeletar);

// ========== PROFESSORES ==========
router.get('/professores', ctrl.professoresListar);
router.get('/professores/:id', ctrl.professoresBuscar);
router.post('/professores', ctrl.professoresCriar);
router.put('/professores/:id', ctrl.professoresAtualizar);
router.delete('/professores/:id', ctrl.professoresDeletar);
router.get('/professores/:id/turmas', ctrl.professoresTurmas);
router.get('/professores/:id/cursos', ctrl.professoresCursos);

// ========== DEPARTAMENTOS ==========
router.get('/departamentos', ctrl.departamentosListar);
router.get('/departamentos/:id', ctrl.departamentosBuscar);
router.post('/departamentos', ctrl.departamentosCriar);
router.put('/departamentos/:id', ctrl.departamentosAtualizar);
router.delete('/departamentos/:id', ctrl.departamentosDeletar);
router.get('/departamentos/:id/professores', ctrl.departamentosProfessores);
router.get('/departamentos/:id/cursos', ctrl.departamentosCursos);
router.get('/departamentos/:id/disciplinas', ctrl.departamentosDisciplinas);

// ========== CURSOS ==========
router.get('/cursos', ctrl.cursosListar);
router.get('/cursos/:id', ctrl.cursosBuscar);
router.post('/cursos', ctrl.cursosCriar);
router.put('/cursos/:id', ctrl.cursosAtualizar);
router.delete('/cursos/:id', ctrl.cursosDeletar);
router.get('/cursos/:id/grade', ctrl.cursosGrade);
router.get('/cursos/:id/disciplinas', ctrl.cursosDisciplinas);
router.get('/cursos/:id/alunos', ctrl.cursosAlunos);
router.get('/cursos/:id/tcc', ctrl.cursosTcc);

// ========== DISCIPLINAS ==========
router.get('/disciplinas', ctrl.disciplinasListar);
router.get('/disciplinas/:id', ctrl.disciplinasBuscar);
router.post('/disciplinas', ctrl.disciplinasCriar);
router.put('/disciplinas/:id', ctrl.disciplinasAtualizar);
router.delete('/disciplinas/:id', ctrl.disciplinasDeletar);

// ========== PRÉ-REQUISITOS ==========
router.get('/pre-requisitos', ctrl.prereqListar);
router.get('/pre-requisitos/:id', ctrl.prereqBuscar);
router.post('/pre-requisitos', ctrl.prereqCriar);
router.delete('/pre-requisitos/:id', ctrl.prereqDeletar);

// ========== GRADE CURRICULAR ==========
router.get('/grade-curricular', ctrl.gradeListar);
router.get('/grade-curricular/:id', ctrl.gradeBuscar);
router.post('/grade-curricular', ctrl.gradeCriar);
router.put('/grade-curricular/:id', ctrl.gradeAtualizar);
router.delete('/grade-curricular/:id', ctrl.gradeDeletar);

// ========== PERÍODOS LETIVOS ==========
router.get('/periodos-letivos', ctrl.periodosListar);
router.get('/periodos-letivos/:id', ctrl.periodosBuscar);
router.post('/periodos-letivos', ctrl.periodosCriar);
router.put('/periodos-letivos/:id', ctrl.periodosAtualizar);
router.delete('/periodos-letivos/:id', ctrl.periodosDeletar);

// ========== TURMAS ==========
router.get('/turmas', ctrl.turmasListar);
router.get('/turmas/:id', ctrl.turmasBuscar);
router.post('/turmas', ctrl.turmasCriar);
router.put('/turmas/:id', ctrl.turmasAtualizar);
router.delete('/turmas/:id', ctrl.turmasDeletar);
router.get('/turmas/:id/alunos', ctrl.turmasAlunos);
router.get('/turmas/:id/avaliacoes', ctrl.turmasAvaliacoes);
router.get('/turmas/:id/plano-ensino', ctrl.turmasPlano);

// ========== MATRÍCULAS EM TURMA ==========
router.get('/matriculas-turma', ctrl.mtListar);
router.get('/matriculas-turma/:id', ctrl.mtBuscar);
router.post('/matriculas-turma', ctrl.mtCriar);
router.put('/matriculas-turma/:id', ctrl.mtAtualizar);
router.delete('/matriculas-turma/:id', ctrl.mtDeletar);

// ========== AVALIAÇÕES ==========
router.get('/avaliacoes', ctrl.avaliacoesListar);
router.get('/avaliacoes/:id', ctrl.avaliacoesBuscar);
router.post('/avaliacoes', ctrl.avaliacoesCriar);
router.put('/avaliacoes/:id', ctrl.avaliacoesAtualizar);
router.delete('/avaliacoes/:id', ctrl.avaliacoesDeletar);

// ========== NOTAS ==========
router.get('/notas', ctrl.notasListar);
router.get('/notas/:id', ctrl.notasBuscar);
router.post('/notas', ctrl.notasCriar);
router.put('/notas/:id', ctrl.notasAtualizar);
router.delete('/notas/:id', ctrl.notasDeletar);

// ========== FREQUÊNCIAS ==========
router.get('/frequencias', ctrl.freqListar);
router.get('/frequencias/:id', ctrl.freqBuscar);
router.post('/frequencias', ctrl.freqCriar);
router.put('/frequencias/:id', ctrl.freqAtualizar);
router.delete('/frequencias/:id', ctrl.freqDeletar);

// ========== HISTÓRICO ==========
router.get('/historico', ctrl.histListar);
router.get('/historico/:id', ctrl.histBuscar);
router.post('/historico', ctrl.histCriar);
router.put('/historico/:id', ctrl.histAtualizar);
router.delete('/historico/:id', ctrl.histDeletar);

// ========== PLANO DE ENSINO ==========
router.get('/planos-ensino', ctrl.planoListar);
router.get('/planos-ensino/:id', ctrl.planoBuscar);
router.post('/planos-ensino', ctrl.planoCriar);
router.put('/planos-ensino/:id', ctrl.planoAtualizar);
router.delete('/planos-ensino/:id', ctrl.planoDeletar);

// ========== ATIVIDADES COMPLEMENTARES ==========
router.get('/atividades', ctrl.ativListar);
router.get('/atividades/:id', ctrl.ativBuscar);
router.post('/atividades', ctrl.ativCriar);
router.put('/atividades/:id', ctrl.ativAtualizar);
router.delete('/atividades/:id', ctrl.ativDeletar);

// ========== TCC ==========
router.get('/tcc', ctrl.tccListar);
router.get('/tcc/:id', ctrl.tccBuscar);
router.post('/tcc', ctrl.tccCriar);
router.put('/tcc/:id', ctrl.tccAtualizar);
router.delete('/tcc/:id', ctrl.tccDeletar);

// ========== MENSAGENS ==========
router.get('/mensagens', ctrl.msgListar);
router.get('/mensagens/:id', ctrl.msgBuscar);
router.post('/mensagens', ctrl.msgCriar);
router.put('/mensagens/:id', ctrl.msgAtualizar);
router.delete('/mensagens/:id', ctrl.msgDeletar);


module.exports = router;
