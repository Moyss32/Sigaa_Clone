const pool = require('../config/db');

// Helpers
const buildLike = (q) => q ? `%${q}%` : null;
const orderDir = (v) => (String(v||'asc').toLowerCase()==='desc' ? 'DESC' : 'ASC');

// Alunos
exports.alunosListar = async (req, res) => {
  try {
    const { page = 1, limit = 20, sort = 'id_aluno', order = 'asc', status_aluno, cpf, matricula, q } = req.query;
    const off = (Number(page) - 1) * Number(limit);
    const where = [];
    const params = [];
    if (status_aluno) { params.push(status_aluno); where.push(`status_aluno = $${params.length}`); }
    if (cpf) { params.push(cpf); where.push(`cpf = $${params.length}`); }
    if (matricula) { params.push(matricula); where.push(`matricula = $${params.length}`); }
    if (q) { params.push(buildLike(q), buildLike(q)); where.push(`(unaccent(nome_completo) ILIKE unaccent($${params.length-1}) OR unaccent(email) ILIKE unaccent($${params.length}))`); }
    const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
    const total = await pool.query(`SELECT COUNT(*) FROM alunos ${whereSql}`, params);
    const rows = await pool.query(
      `SELECT * FROM alunos ${whereSql} ORDER BY ${sort} ${orderDir(order)} LIMIT $${params.length+1} OFFSET $${params.length+2}`,
      [...params, Number(limit), off]
    );
    res.json({ total: Number(total.rows[0].count), page: Number(page), limit: Number(limit), data: rows.rows });
  } catch (e) {
    res.status(500).json({ message: 'Erro ao listar alunos', details: e.message });
  }
};

exports.alunosBuscar = async (req, res) => {
  try {
    const r = await pool.query('SELECT * FROM alunos WHERE id_aluno=$1', [req.params.id]);
    if (!r.rowCount) return res.status(404).json({ message: 'Aluno não encontrado' });
    res.json(r.rows[0]);
  } catch (e) { res.status(500).json({ message: 'Erro ao buscar aluno', details: e.message }); }
};

exports.alunosCriar = async (req, res) => {
  const client = await pool.connect();
  try {
    const { matricula, cpf, nome_completo, email, telefone, data_nascimento, endereco, cidade, estado, cep, data_ingresso, status_aluno } = req.body;
    await client.query('BEGIN');
    const sql = `INSERT INTO alunos (matricula, cpf, nome_completo, email, telefone, data_nascimento, endereco, cidade, estado, cep, data_ingresso, status_aluno)
                 VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,COALESCE($12,'ativo')) RETURNING *`;
    const r = await client.query(sql, [matricula, cpf, nome_completo, email, telefone||null, data_nascimento, endereco||null, cidade||null, estado||null, cep||null, data_ingresso, status_aluno||null]);
    await client.query('COMMIT');
    res.status(201).json(r.rows[0]);
  } catch (e) {
    await client.query('ROLLBACK');
    res.status(400).json({ message: 'Erro ao cadastrar aluno', details: e.message });
  } finally { client.release(); }
};

exports.alunosAtualizar = async (req, res) => {
  try {
    const fields = ['matricula','cpf','nome_completo','email','telefone','data_nascimento','endereco','cidade','estado','cep','data_ingresso','status_aluno'];
    const set=[], vals=[];
    fields.forEach(f=>{ if (f in req.body) { vals.push(req.body[f]); set.push(`${f}=$${vals.length}`); } });
    if (!set.length) return res.status(400).json({ message:'Nenhum campo para atualizar' });
    vals.push(req.params.id);
    const r = await pool.query(`UPDATE alunos SET ${set.join(', ')} WHERE id_aluno=$${vals.length} RETURNING *`, vals);
    if (!r.rowCount) return res.status(404).json({ message:'Aluno não encontrado' });
    res.json(r.rows[0]);
  } catch(e){ res.status(400).json({ message:'Erro ao atualizar aluno', details:e.message }); }
};

exports.alunosDeletar = async (req, res) => {
  try {
    const r = await pool.query('DELETE FROM alunos WHERE id_aluno=$1', [req.params.id]);
    if (!r.rowCount) return res.status(404).json({ message: 'Aluno não encontrado' });
    res.status(204).send();
  } catch (e) { res.status(400).json({ message:'Erro ao deletar aluno', details:e.message }); }
};

// Professores
exports.professoresListar = async (req,res)=>{
  try {
    const { departamento_id, status_professor, q } = req.query;
    const where=[], p=[];
    if (departamento_id){ p.push(departamento_id); where.push(`departamento_id=$${p.length}`); }
    if (status_professor){ p.push(status_professor); where.push(`status_professor=$${p.length}`); }
    if (q){ p.push(buildLike(q), buildLike(q)); where.push(`(unaccent(nome_completo) ILIKE unaccent($${p.length-1}) OR unaccent(email) ILIKE unaccent($${p.length}))`); }
    const r = await pool.query(`SELECT * FROM professores ${where.length?'WHERE '+where.join(' AND '):''} ORDER BY id_professor DESC`, p);
    res.json(r.rows);
  } catch(e){ res.status(500).json({ message:'Erro ao listar professores', details:e.message }); }
};

exports.professoresBuscar = async (req,res)=>{
  try{
    const r = await pool.query('SELECT * FROM professores WHERE id_professor=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Professor não encontrado'});
    res.json(r.rows[0]);
  } catch(e){ res.status(500).json({message:'Erro ao buscar professor', details:e.message}); }
};

exports.professoresCriar = async (req,res)=>{
  const client = await pool.connect();
  try{
    const { matricula, cpf, nome_completo, email, telefone, data_nascimento, titulacao, data_contratacao, departamento_id, status_professor } = req.body;
    await client.query('BEGIN');
    const r = await client.query(`
      INSERT INTO professores (matricula, cpf, nome_completo, email, telefone, data_nascimento, titulacao, data_contratacao, departamento_id, status_professor)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,COALESCE($10,'ativo')) RETURNING *`,
      [matricula, cpf, nome_completo, email, telefone||null, data_nascimento||null, titulacao, data_contratacao, departamento_id, status_professor||null]
    );
    await client.query('COMMIT');
    res.status(201).json(r.rows[0]);
  } catch(e){
    await client.query('ROLLBACK');
    res.status(400).json({message:'Erro ao cadastrar professor', details:e.message});
  } finally { client.release(); }
};

exports.professoresAtualizar = async (req,res)=>{
  try{
    const fields = ['matricula','cpf','nome_completo','email','telefone','data_nascimento','titulacao','data_contratacao','departamento_id','status_professor'];
    const set=[], vals=[];
    fields.forEach(f=>{ if(f in req.body){ vals.push(req.body[f]); set.push(`${f}=$${vals.length}`);} });
    if(!set.length) return res.status(400).json({message:'Nenhum campo para atualizar'});
    vals.push(req.params.id);
    const r = await pool.query(`UPDATE professores SET ${set.join(', ')} WHERE id_professor=$${vals.length} RETURNING *`, vals);
    if(!r.rowCount) return res.status(404).json({message:'Professor não encontrado'});
    res.json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao atualizar professor', details:e.message}); }
};

exports.professoresDeletar = async (req,res)=>{
  try{
    const r = await pool.query('DELETE FROM professores WHERE id_professor=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Professor não encontrado'});
    res.status(204).send();
  } catch(e){ res.status(400).json({message:'Erro ao deletar professor', details:e.message}); }
};

exports.professoresTurmas = async (req,res)=>{
  try{ const r = await pool.query('SELECT * FROM turmas WHERE professor_id=$1 ORDER BY id_turma DESC',[req.params.id]); res.json(r.rows); }
  catch(e){ res.status(500).json({message:'Erro ao listar turmas', details:e.message}); }
};
exports.professoresCursos = async (req,res)=>{
  try{ const r = await pool.query('SELECT * FROM cursos WHERE coordenador_id=$1 ORDER BY id_curso DESC',[req.params.id]); res.json(r.rows); }
  catch(e){ res.status(500).json({message:'Erro ao listar cursos', details:e.message}); }
};

// Departamentos
exports.departamentosListar = async (req,res)=>{
  try{
    const { q } = req.query;
    const p=[]; const where=[];
    if(q){ p.push(`%${q}%`,`%${q}%`); where.push('(codigo ILIKE $1 OR unaccent(nome) ILIKE unaccent($2))'); }
    const r = await pool.query(`SELECT * FROM departamentos ${where.length?'WHERE '+where.join(' AND '):''} ORDER BY id_departamento DESC`, p);
    res.json(r.rows);
  } catch(e){ res.status(500).json({message:'Erro ao listar departamentos', details:e.message}); }
};

exports.departamentosBuscar = async (req,res)=>{
  try{
    const r = await pool.query('SELECT * FROM departamentos WHERE id_departamento=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Departamento não encontrado'});
    res.json(r.rows[0]);
  } catch(e){ res.status(500).json({message:'Erro ao buscar departamento', details:e.message}); }
};

exports.departamentosCriar = async (req,res)=>{
  try{
    const { codigo, nome, coordenador_id, telefone, email } = req.body;
    const r = await pool.query(`INSERT INTO departamentos (codigo, nome, coordenador_id, telefone, email)
      VALUES ($1,$2,$3,$4,$5) RETURNING *`, [codigo, nome, coordenador_id||null, telefone||null, email||null]);
    res.status(201).json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao cadastrar departamento', details:e.message}); }
};

exports.departamentosAtualizar = async (req,res)=>{
  try{
    const fields = ['codigo','nome','coordenador_id','telefone','email'];
    const set=[], vals=[];
    fields.forEach(f=>{ if(f in req.body){ vals.push(req.body[f]); set.push(`${f}=$${vals.length}`);} });
    if(!set.length) return res.status(400).json({message:'Nenhum campo para atualizar'});
    vals.push(req.params.id);
    const r = await pool.query(`UPDATE departamentos SET ${set.join(', ')} WHERE id_departamento=$${vals.length} RETURNING *`, vals);
    if(!r.rowCount) return res.status(404).json({message:'Departamento não encontrado'});
    res.json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao atualizar departamento', details:e.message}); }
};

exports.departamentosDeletar = async (req,res)=>{
  try{
    const r = await pool.query('DELETE FROM departamentos WHERE id_departamento=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Departamento não encontrado'});
    res.status(204).send();
  } catch(e){ res.status(400).json({message:'Erro ao deletar departamento', details:e.message}); }
};

exports.departamentosProfessores = async (req,res)=>{
  try{ const r = await pool.query('SELECT * FROM professores WHERE departamento_id=$1',[req.params.id]); res.json(r.rows); }
  catch(e){ res.status(500).json({message:'Erro ao listar professores', details:e.message}); }
};
exports.departamentosCursos = async (req,res)=>{
  try{ const r = await pool.query('SELECT * FROM cursos WHERE departamento_id=$1',[req.params.id]); res.json(r.rows); }
  catch(e){ res.status(500).json({message:'Erro ao listar cursos', details:e.message}); }
};
exports.departamentosDisciplinas = async (req,res)=>{
  try{ const r = await pool.query('SELECT * FROM disciplinas WHERE departamento_id=$1',[req.params.id]); res.json(r.rows); }
  catch(e){ res.status(500).json({message:'Erro ao listar disciplinas', details:e.message}); }
};

// Cursos
exports.cursosListar = async (req,res)=>{
  try{
    const { departamento_id, status_curso, q } = req.query;
    const where=[], p=[];
    if (departamento_id){ p.push(departamento_id); where.push(`departamento_id=$${p.length}`); }
    if (status_curso){ p.push(status_curso); where.push(`status_curso=$${p.length}`); }
    if (q){ p.push(buildLike(q), buildLike(q)); where.push(`(codigo ILIKE $${p.length-1} OR unaccent(nome) ILIKE unaccent($${p.length}))`); }
    const r = await pool.query(`SELECT * FROM cursos ${where.length?'WHERE '+where.join(' AND '):''} ORDER BY id_curso DESC`, p);
    res.json(r.rows);
  } catch(e){ res.status(500).json({message:'Erro ao listar cursos', details:e.message}); }
};

exports.cursosBuscar = async (req,res)=>{
  try{
    const r = await pool.query('SELECT * FROM cursos WHERE id_curso=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Curso não encontrado'});
    res.json(r.rows[0]);
  } catch(e){ res.status(500).json({message:'Erro ao buscar curso', details:e.message}); }
};

exports.cursosCriar = async (req,res)=>{
  try{
    const { codigo, nome, grau, duracao_semestres, carga_horaria_total, departamento_id, coordenador_id, data_criacao, status_curso } = req.body;
    const r = await pool.query(`
      INSERT INTO cursos (codigo, nome, grau, duracao_semestres, carga_horaria_total, departamento_id, coordenador_id, data_criacao, status_curso)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,COALESCE($9,'ativo')) RETURNING *`,
      [codigo, nome, grau, duracao_semestres, carga_horaria_total, departamento_id, coordenador_id||null, data_criacao, status_curso||null]
    );
    res.status(201).json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao cadastrar curso', details:e.message}); }
};

exports.cursosAtualizar = async (req,res)=>{
  try{
    const fields=['codigo','nome','grau','duracao_semestres','carga_horaria_total','departamento_id','coordenador_id','data_criacao','status_curso'];
    const set=[], vals=[];
    fields.forEach(f=>{ if(f in req.body){ vals.push(req.body[f]); set.push(`${f}=$${vals.length}`);} });
    if(!set.length) return res.status(400).json({message:'Nenhum campo para atualizar'});
    vals.push(req.params.id);
    const r = await pool.query(`UPDATE cursos SET ${set.join(', ')} WHERE id_curso=$${vals.length} RETURNING *`, vals);
    if(!r.rowCount) return res.status(404).json({message:'Curso não encontrado'});
    res.json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao atualizar curso', details:e.message}); }
};

exports.cursosDeletar = async (req,res)=>{
  try{
    const r = await pool.query('DELETE FROM cursos WHERE id_curso=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Curso não encontrado'});
    res.status(204).send();
  } catch(e){ res.status(400).json({message:'Erro ao deletar curso', details:e.message}); }
};

exports.cursosGrade = async (req,res)=>{
  try{
    const { ano_vigencia } = req.query;
    const p=[req.params.id]; let w='WHERE gc.curso_id=$1';
    if(ano_vigencia){ p.push(ano_vigencia); w+=' AND gc.ano_vigencia=$2'; }
    const r = await pool.query(`
      SELECT gc.*, d.codigo as disciplina_codigo, d.nome as disciplina_nome
      FROM grade_curricular gc
      JOIN disciplinas d ON d.id_disciplina = gc.disciplina_id
      ${w} ORDER BY gc.periodo_recomendado, d.nome`, p);
    res.json(r.rows);
  } catch(e){ res.status(500).json({message:'Erro ao listar grade', details:e.message}); }
};

exports.cursosDisciplinas = async (req,res)=>{
  try{
    const r = await pool.query(`
      SELECT DISTINCT d.*
      FROM grade_curricular gc
      JOIN disciplinas d ON d.id_disciplina = gc.disciplina_id
      WHERE gc.curso_id=$1
      ORDER BY d.nome`, [req.params.id]);
    res.json(r.rows);
  } catch(e){ res.status(500).json({message:'Erro ao listar disciplinas do curso', details:e.message}); }
};

exports.cursosAlunos = async (req,res)=>{
  try{
    const r = await pool.query(`
      SELECT a.*
      FROM matriculas_curso mc
      JOIN alunos a ON a.id_aluno = mc.aluno_id
      WHERE mc.curso_id=$1 AND mc.status='ativo'
      ORDER BY a.nome_completo`, [req.params.id]);
    res.json(r.rows);
  } catch(e){ res.status(500).json({message:'Erro ao listar alunos do curso', details:e.message}); }
};

exports.cursosTcc = async (req,res)=>{
  try{
    const r = await pool.query('SELECT * FROM tcc WHERE curso_id=$1 ORDER BY id_tcc DESC',[req.params.id]);
    res.json(r.rows);
  } catch(e){ res.status(500).json({message:'Erro ao listar TCCs', details:e.message}); }
};

// Disciplinas
exports.disciplinasListar = async (req,res)=>{
  try{
    const { departamento_id, tipo, q } = req.query;
    const where=[], p=[];
    if (departamento_id){ p.push(departamento_id); where.push(`departamento_id=$${p.length}`); }
    if (tipo){ p.push(tipo); where.push(`tipo=$${p.length}`); }
    if (q){ p.push(buildLike(q), buildLike(q)); where.push(`(codigo ILIKE $${p.length-1} OR unaccent(nome) ILIKE unaccent($${p.length}))`); }
    const r = await pool.query(`SELECT * FROM disciplinas ${where.length?'WHERE '+where.join(' AND '):''} ORDER BY id_disciplina DESC`, p);
    res.json(r.rows);
  } catch(e){ res.status(500).json({message:'Erro ao listar disciplinas', details:e.message}); }
};

exports.disciplinasBuscar = async (req,res)=>{
  try{
    const r = await pool.query('SELECT * FROM disciplinas WHERE id_disciplina=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Disciplina não encontrada'});
    res.json(r.rows[0]);
  } catch(e){ res.status(500).json({message:'Erro ao buscar disciplina', details:e.message}); }
};

exports.disciplinasCriar = async (req,res)=>{
  try{
    const { codigo, nome, carga_horaria, creditos, ementa, bibliografia, departamento_id, tipo } = req.body;
    const r = await pool.query(`
      INSERT INTO disciplinas (codigo, nome, carga_horaria, creditos, ementa, bibliografia, departamento_id, tipo)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [codigo, nome, carga_horaria, creditos, ementa||null, bibliografia||null, departamento_id, tipo]
    );
    res.status(201).json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao cadastrar disciplina', details:e.message}); }
};

exports.disciplinasAtualizar = async (req,res)=>{
  try{
    const fields=['codigo','nome','carga_horaria','creditos','ementa','bibliografia','departamento_id','tipo'];
    const set=[], vals=[];
    fields.forEach(f=>{ if(f in req.body){ vals.push(req.body[f]); set.push(`${f}=$${vals.length}`);} });
    if(!set.length) return res.status(400).json({message:'Nenhum campo para atualizar'});
    vals.push(req.params.id);
    const r = await pool.query(`UPDATE disciplinas SET ${set.join(', ')} WHERE id_disciplina=$${vals.length} RETURNING *`, vals);
    if(!r.rowCount) return res.status(404).json({message:'Disciplina não encontrada'});
    res.json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao atualizar disciplina', details:e.message}); }
};

exports.disciplinasDeletar = async (req,res)=>{
  try{
    const r = await pool.query('DELETE FROM disciplinas WHERE id_disciplina=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Disciplina não encontrada'});
    res.status(204).send();
  } catch(e){ res.status(400).json({message:'Erro ao deletar disciplina', details:e.message}); }
};

// Pré-requisitos
exports.prereqListar = async (req,res)=>{
  try{
    const { disciplina_id } = req.query;
    const p=[], w=[];
    if (disciplina_id){ p.push(disciplina_id); w.push(`disciplina_id=$1`); }
    const r = await pool.query(`SELECT * FROM pre_requisitos ${w.length?'WHERE '+w.join(' AND '):''} ORDER BY id_pre_requisito DESC`, p);
    res.json(r.rows);
  } catch(e){ res.status(500).json({message:'Erro ao listar pré-requisitos', details:e.message}); }
};
exports.prereqBuscar = async (req,res)=>{
  try{
    const r = await pool.query('SELECT * FROM pre_requisitos WHERE id_pre_requisito=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Pré-requisito não encontrado'});
    res.json(r.rows[0]);
  } catch(e){ res.status(500).json({message:'Erro ao buscar pré-requisito', details:e.message}); }
};
exports.prereqCriar = async (req,res)=>{
  try{
    const { disciplina_id, disciplina_requisito_id, tipo_requisito } = req.body;
    const r = await pool.query(`INSERT INTO pre_requisitos (disciplina_id, disciplina_requisito_id, tipo_requisito)
      VALUES ($1,$2,$3) RETURNING *`, [disciplina_id, disciplina_requisito_id, tipo_requisito]);
    res.status(201).json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao cadastrar pré-requisito', details:e.message}); }
};
exports.prereqDeletar = async (req,res)=>{
  try{
    const r = await pool.query('DELETE FROM pre_requisitos WHERE id_pre_requisito=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Pré-requisito não encontrado'});
    res.status(204).send();
  } catch(e){ res.status(400).json({message:'Erro ao deletar pré-requisito', details:e.message}); }
};

// Grade Curricular
exports.gradeListar = async (req,res)=>{
  try{
    const { curso_id, ano_vigencia } = req.query;
    const p=[], w=[];
    if (curso_id){ p.push(curso_id); w.push(`curso_id=$${p.length}`); }
    if (ano_vigencia){ p.push(ano_vigencia); w.push(`ano_vigencia=$${p.length}`); }
    const r = await pool.query(`SELECT * FROM grade_curricular ${w.length?'WHERE '+w.join(' AND '):''} ORDER BY periodo_recomendado`, p);
    res.json(r.rows);
  } catch(e){ res.status(500).json({message:'Erro ao listar grade', details:e.message}); }
};
exports.gradeBuscar = async (req,res)=>{
  try{
    const r = await pool.query('SELECT * FROM grade_curricular WHERE id_grade=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Grade não encontrada'});
    res.json(r.rows[0]);
  } catch(e){ res.status(500).json({message:'Erro ao buscar grade', details:e.message}); }
};
exports.gradeCriar = async (req,res)=>{
  try{
    const { curso_id, disciplina_id, periodo_recomendado, obrigatoria, ano_vigencia } = req.body;
    const r = await pool.query(`INSERT INTO grade_curricular (curso_id, disciplina_id, periodo_recomendado, obrigatoria, ano_vigencia)
      VALUES ($1,$2,$3,$4,$5) RETURNING *`, [curso_id, disciplina_id, periodo_recomendado, obrigatoria, ano_vigencia]);
    res.status(201).json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao cadastrar grade', details:e.message}); }
};
exports.gradeAtualizar = async (req,res)=>{
  try{
    const fields=['curso_id','disciplina_id','periodo_recomendado','obrigatoria','ano_vigencia'];
    const set=[], vals=[];
    fields.forEach(f=>{ if(f in req.body){ vals.push(req.body[f]); set.push(`${f}=$${vals.length}`);} });
    if(!set.length) return res.status(400).json({message:'Nenhum campo para atualizar'});
    vals.push(req.params.id);
    const r = await pool.query(`UPDATE grade_curricular SET ${set.join(', ')} WHERE id_grade=$${vals.length} RETURNING *`, vals);
    if(!r.rowCount) return res.status(404).json({message:'Grade não encontrada'});
    res.json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao atualizar grade', details:e.message}); }
};
exports.gradeDeletar = async (req,res)=>{
  try{
    const r = await pool.query('DELETE FROM grade_curricular WHERE id_grade=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Grade não encontrada'});
    res.status(204).send();
  } catch(e){ res.status(400).json({message:'Erro ao deletar grade', details:e.message}); }
};

// Períodos letivos
exports.periodosListar = async (req,res)=>{
  try{
    const { ano, semestre, status } = req.query;
    const p=[], w=[];
    if(ano){ p.push(ano); w.push(`ano=$${p.length}`); }
    if(semestre){ p.push(semestre); w.push(`semestre=$${p.length}`); }
    if(status){ p.push(status); w.push(`status=$${p.length}`); }
    const r = await pool.query(`SELECT * FROM periodos_letivos ${w.length?'WHERE '+w.join(' AND '):''} ORDER BY ano DESC, semestre DESC`, p);
    res.json(r.rows);
  } catch(e){ res.status(500).json({message:'Erro ao listar períodos letivos', details:e.message}); }
};
exports.periodosBuscar = async (req,res)=>{
  try{
    const r = await pool.query('SELECT * FROM periodos_letivos WHERE id_periodo_letivo=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Período letivo não encontrado'});
    res.json(r.rows[0]);
  } catch(e){ res.status(500).json({message:'Erro ao buscar período letivo', details:e.message}); }
};
exports.periodosCriar = async (req,res)=>{
  try{
    const { ano, semestre, data_inicio, data_fim, data_inicio_matriculas, data_fim_matriculas, status } = req.body;
    const r = await pool.query(`
      INSERT INTO periodos_letivos (ano, semestre, data_inicio, data_fim, data_inicio_matriculas, data_fim_matriculas, status)
      VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [ano, semestre, data_inicio, data_fim, data_inicio_matriculas, data_fim_matriculas, status]
    );
    res.status(201).json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao cadastrar período letivo', details:e.message}); }
};
exports.periodosAtualizar = async (req,res)=>{
  try{
    const fields=['ano','semestre','data_inicio','data_fim','data_inicio_matriculas','data_fim_matriculas','status'];
    const set=[], vals=[];
    fields.forEach(f=>{ if(f in req.body){ vals.push(req.body[f]); set.push(`${f}=$${vals.length}`);} });
    if(!set.length) return res.status(400).json({message:'Nenhum campo para atualizar'});
    vals.push(req.params.id);
    const r = await pool.query(`UPDATE periodos_letivos SET ${set.join(', ')} WHERE id_periodo_letivo=$${vals.length} RETURNING *`, vals);
    if(!r.rowCount) return res.status(404).json({message:'Período letivo não encontrado'});
    res.json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao atualizar período letivo', details:e.message}); }
};
exports.periodosDeletar = async (req,res)=>{
  try{
    const r = await pool.query('DELETE FROM periodos_letivos WHERE id_periodo_letivo=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Período letivo não encontrado'});
    res.status(204).send();
  } catch(e){ res.status(400).json({message:'Erro ao deletar período letivo', details:e.message}); }
};

// Turmas
exports.turmasListar = async (req,res)=>{
  try{
    const { disciplina_id, periodo_letivo_id, professor_id, status_turma, q } = req.query;
    const w=[], p=[];
    if(disciplina_id){ p.push(disciplina_id); w.push(`disciplina_id=$${p.length}`); }
    if(periodo_letivo_id){ p.push(periodo_letivo_id); w.push(`periodo_letivo_id=$${p.length}`); }
    if(professor_id){ p.push(professor_id); w.push(`professor_id=$${p.length}`); }
    if(status_turma){ p.push(status_turma); w.push(`status_turma=$${p.length}`); }
    if (q){ p.push(buildLike(q)); w.push(`codigo ILIKE $${p.length}`); }
    const r = await pool.query(`SELECT * FROM turmas ${w.length?'WHERE '+w.join(' AND '):''} ORDER BY id_turma DESC`, p);
    res.json(r.rows);
  } catch(e){ res.status(500).json({message:'Erro ao listar turmas', details:e.message}); }
};
exports.turmasBuscar = async (req,res)=>{
  try{
    const r = await pool.query('SELECT * FROM turmas WHERE id_turma=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Turma não encontrada'});
    res.json(r.rows[0]);
  } catch(e){ res.status(500).json({message:'Erro ao buscar turma', details:e.message}); }
};
exports.turmasCriar = async (req,res)=>{
  try{
    const { codigo, disciplina_id, periodo_letivo_id, professor_id, vagas_total, horario, sala, dias_semana, status_turma } = req.body;
    const r = await pool.query(`
      INSERT INTO turmas (codigo, disciplina_id, periodo_letivo_id, professor_id, vagas_total, horario, sala, dias_semana, status_turma)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [codigo, disciplina_id, periodo_letivo_id, professor_id, vagas_total, horario, sala||null, dias_semana, status_turma]
    );
    res.status(201).json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao cadastrar turma', details:e.message}); }
};
exports.turmasAtualizar = async (req,res)=>{
  try{
    const fields=['codigo','disciplina_id','periodo_letivo_id','professor_id','vagas_total','vagas_ocupadas','horario','sala','dias_semana','status_turma'];
    const set=[], vals=[];
    fields.forEach(f=>{ if(f in req.body){ vals.push(req.body[f]); set.push(`${f}=$${vals.length}`);} });
    if(!set.length) return res.status(400).json({message:'Nenhum campo para atualizar'});
    vals.push(req.params.id);
    const r = await pool.query(`UPDATE turmas SET ${set.join(', ')} WHERE id_turma=$${vals.length} RETURNING *`, vals);
    if(!r.rowCount) return res.status(404).json({message:'Turma não encontrada'});
    res.json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao atualizar turma', details:e.message}); }
};
exports.turmasDeletar = async (req,res)=>{
  try{
    const r = await pool.query('DELETE FROM turmas WHERE id_turma=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Turma não encontrada'});
    res.status(204).send();
  } catch(e){ res.status(400).json({message:'Erro ao deletar turma', details:e.message}); }
};
exports.turmasAlunos = async (req,res)=>{
  try{
    const r = await pool.query(`
      SELECT mt.*, a.nome_completo, a.matricula
      FROM matriculas_turma mt
      JOIN alunos a ON a.id_aluno = mt.aluno_id
      WHERE mt.turma_id=$1`, [req.params.id]);
    res.json(r.rows);
  } catch(e){ res.status(500).json({message:'Erro ao listar alunos da turma', details:e.message}); }
};
exports.turmasAvaliacoes = async (req,res)=>{
  try{
    const r = await pool.query(`SELECT * FROM avaliacoes WHERE turma_id=$1 ORDER BY data_avaliacao`, [req.params.id]);
    res.json(r.rows);
  } catch(e){ res.status(500).json({message:'Erro ao listar avaliações', details:e.message}); }
};
exports.turmasPlano = async (req,res)=>{
  try{
    const r = await pool.query(`SELECT * FROM planos_ensino WHERE turma_id=$1`, [req.params.id]);
    res.json(r.rows[0] || null);
  } catch(e){ res.status(500).json({message:'Erro ao buscar plano de ensino', details:e.message}); }
};

// Matrículas em turma
exports.mtListar = async (req,res)=>{
  try{
    const { aluno_id, turma_id, situacao } = req.query;
    const w=[], p=[];
    if(aluno_id){ p.push(aluno_id); w.push(`aluno_id=$${p.length}`); }
    if(turma_id){ p.push(turma_id); w.push(`turma_id=$${p.length}`); }
    if(situacao){ p.push(situacao); w.push(`situacao=$${p.length}`); }
    const r = await pool.query(`SELECT * FROM matriculas_turma ${w.length?'WHERE '+w.join(' AND '):''} ORDER BY id_matricula_turma DESC`, p);
    res.json(r.rows);
  } catch(e){ res.status(500).json({message:'Erro ao listar matrículas', details:e.message}); }
};
exports.mtBuscar = async (req,res)=>{
  try{
    const r = await pool.query('SELECT * FROM matriculas_turma WHERE id_matricula_turma=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Matrícula não encontrada'});
    res.json(r.rows[0]);
  } catch(e){ res.status(500).json({message:'Erro ao buscar matrícula', details:e.message}); }
};
exports.mtCriar = async (req,res)=>{
  const client = await pool.connect();
  try{
    const { aluno_id, turma_id, data_matricula, situacao } = req.body;
    await client.query('BEGIN');
    const t = await client.query('SELECT vagas_total, vagas_ocupadas FROM turmas WHERE id_turma=$1 FOR UPDATE',[turma_id]);
    if(!t.rowCount) throw new Error('Turma inexistente');
    const tm = t.rows[0];
    if (tm.vagas_ocupadas >= tm.vagas_total) throw new Error('Sem vagas');
    const ja = await client.query('SELECT 1 FROM matriculas_turma WHERE aluno_id=$1 AND turma_id=$2',[aluno_id, turma_id]);
    if (ja.rowCount) throw new Error('Já matriculado');
    const r = await client.query(`
      INSERT INTO matriculas_turma (aluno_id, turma_id, data_matricula, situacao)
      VALUES ($1,$2,$3,COALESCE($4,'matriculado')) RETURNING *`,
      [aluno_id, turma_id, data_matricula, situacao||null]);
    await client.query('UPDATE turmas SET vagas_ocupadas = vagas_ocupadas + 1 WHERE id_turma=$1',[turma_id]);
    await client.query('COMMIT');
    res.status(201).json(r.rows[0]);
  } catch(e){
    await client.query('ROLLBACK');
    res.status(400).json({message:'Erro ao matricular na turma', details:e.message});
  } finally { client.release(); }
};
exports.mtAtualizar = async (req,res)=>{
  try{
    const fields=['aluno_id','turma_id','data_matricula','situacao'];
    const set=[], vals=[];
    fields.forEach(f=>{ if(f in req.body){ vals.push(req.body[f]); set.push(`${f}=$${vals.length}`);} });
    if(!set.length) return res.status(400).json({message:'Nenhum campo para atualizar'});
    vals.push(req.params.id);
    const r = await pool.query(`UPDATE matriculas_turma SET ${set.join(', ')} WHERE id_matricula_turma=$${vals.length} RETURNING *`, vals);
    if(!r.rowCount) return res.status(404).json({message:'Matrícula não encontrada'});
    res.json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao atualizar matrícula', details:e.message}); }
};
exports.mtDeletar = async (req,res)=>{
  const client = await pool.connect();
  try{
    await client.query('BEGIN');
    const { id } = req.params;
    const m = await client.query('SELECT turma_id FROM matriculas_turma WHERE id_matricula_turma=$1 FOR UPDATE',[id]);
    if(!m.rowCount){ await client.query('ROLLBACK'); return res.status(404).json({message:'Matrícula não encontrada'}); }
    const turmaId = m.rows[0].turma_id;
    const r = await client.query('DELETE FROM matriculas_turma WHERE id_matricula_turma=$1',[id]);
    await client.query('UPDATE turmas SET vagas_ocupadas = GREATEST(vagas_ocupadas - 1, 0) WHERE id_turma=$1',[turmaId]);
    await client.query('COMMIT');
    res.status(204).send();
  } catch(e){
    await client.query('ROLLBACK');
    res.status(400).json({message:'Erro ao deletar matrícula', details:e.message});
  } finally { client.release(); }
};

// Avaliações
exports.avaliacoesListar = async (req,res)=>{
  try{
    const { turma_id, unidade } = req.query;
    const p=[], w=[];
    if(turma_id){ p.push(turma_id); w.push(`turma_id=$${p.length}`); }
    if(unidade){ p.push(unidade); w.push(`unidade=$${p.length}`); }
    const r = await pool.query(`SELECT * FROM avaliacoes ${w.length?'WHERE '+w.join(' AND '):''} ORDER BY data_avaliacao`, p);
    res.json(r.rows);
  } catch(e){ res.status(500).json({message:'Erro ao listar avaliações', details:e.message}); }
};
exports.avaliacoesBuscar = async (req,res)=>{
  try{
    const r = await pool.query('SELECT * FROM avaliacoes WHERE id_avaliacao=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Avaliação não encontrada'});
    res.json(r.rows[0]);
  } catch(e){ res.status(500).json({message:'Erro ao buscar avaliação', details:e.message}); }
};
exports.avaliacoesCriar = async (req,res)=>{
  try{
    const { turma_id, tipo_avaliacao, descricao, data_avaliacao, peso, valor_maximo, unidade } = req.body;
    const r = await pool.query(`
      INSERT INTO avaliacoes (turma_id, tipo_avaliacao, descricao, data_avaliacao, peso, valor_maximo, unidade)
      VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [turma_id, tipo_avaliacao, descricao||null, data_avaliacao, peso, valor_maximo, unidade]);
    res.status(201).json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao cadastrar avaliação', details:e.message}); }
};
exports.avaliacoesAtualizar = async (req,res)=>{
  try{
    const fields=['turma_id','tipo_avaliacao','descricao','data_avaliacao','peso','valor_maximo','unidade'];
    const set=[], vals=[];
    fields.forEach(f=>{ if(f in req.body){ vals.push(req.body[f]); set.push(`${f}=$${vals.length}`);} });
    if(!set.length) return res.status(400).json({message:'Nenhum campo para atualizar'});
    vals.push(req.params.id);
    const r = await pool.query(`UPDATE avaliacoes SET ${set.join(', ')} WHERE id_avaliacao=$${vals.length} RETURNING *`, vals);
    if(!r.rowCount) return res.status(404).json({message:'Avaliação não encontrada'});
    res.json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao atualizar avaliação', details:e.message}); }
};
exports.avaliacoesDeletar = async (req,res)=>{
  try{
    const r = await pool.query('DELETE FROM avaliacoes WHERE id_avaliacao=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Avaliação não encontrada'});
    res.status(204).send();
  } catch(e){ res.status(400).json({message:'Erro ao deletar avaliação', details:e.message}); }
};

// Notas
exports.notasListar = async (req,res)=>{
  try{
    const { matricula_turma_id, avaliacao_id } = req.query;
    const p=[], w=[];
    if(matricula_turma_id){ p.push(matricula_turma_id); w.push(`matricula_turma_id=$${p.length}`); }
    if(avaliacao_id){ p.push(avaliacao_id); w.push(`avaliacao_id=$${p.length}`); }
    const r = await pool.query(`SELECT * FROM notas ${w.length?'WHERE '+w.join(' AND '):''} ORDER BY id_nota DESC`, p);
    res.json(r.rows);
  } catch(e){ res.status(500).json({message:'Erro ao listar notas', details:e.message}); }
};
exports.notasBuscar = async (req,res)=>{
  try{
    const r = await pool.query('SELECT * FROM notas WHERE id_nota=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Nota não encontrada'});
    res.json(r.rows[0]);
  } catch(e){ res.status(500).json({message:'Erro ao buscar nota', details:e.message}); }
};
exports.notasCriar = async (req,res)=>{
  try{
    const { matricula_turma_id, avaliacao_id, nota_obtida, observacao } = req.body;
    const r = await pool.query(`
      INSERT INTO notas (matricula_turma_id, avaliacao_id, nota_obtida, observacao)
      VALUES ($1,$2,$3,$4) RETURNING *`,
      [matricula_turma_id, avaliacao_id, nota_obtida, observacao||null]);
    res.status(201).json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao lançar nota', details:e.message}); }
};
exports.notasAtualizar = async (req,res)=>{
  try{
    const fields=['matricula_turma_id','avaliacao_id','nota_obtida','observacao'];
    const set=[], vals=[];
    fields.forEach(f=>{ if(f in req.body){ vals.push(req.body[f]); set.push(`${f}=$${vals.length}`);} });
    if(!set.length) return res.status(400).json({message:'Nenhum campo para atualizar'});
    vals.push(req.params.id);
    const r = await pool.query(`UPDATE notas SET ${set.join(', ')} WHERE id_nota=$${vals.length} RETURNING *`, vals);
    if(!r.rowCount) return res.status(404).json({message:'Nota não encontrada'});
    res.json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao atualizar nota', details:e.message}); }
};
exports.notasDeletar = async (req,res)=>{
  try{
    const r = await pool.query('DELETE FROM notas WHERE id_nota=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Nota não encontrada'});
    res.status(204).send();
  } catch(e){ res.status(400).json({message:'Erro ao deletar nota', details:e.message}); }
};

// Frequências
exports.freqListar = async (req,res)=>{
  try{
    const { matricula_turma_id, data_aula } = req.query;
    const p=[], w=[];
    if(matricula_turma_id){ p.push(matricula_turma_id); w.push(`matricula_turma_id=$${p.length}`); }
    if(data_aula){ p.push(data_aula); w.push(`data_aula=$${p.length}`); }
    const r = await pool.query(`SELECT * FROM frequencias ${w.length?'WHERE '+w.join(' AND '):''} ORDER BY data_aula DESC`, p);
    res.json(r.rows);
  } catch(e){ res.status(500).json({message:'Erro ao listar frequências', details:e.message}); }
};
exports.freqBuscar = async (req,res)=>{
  try{
    const r = await pool.query('SELECT * FROM frequencias WHERE id_frequencia=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Frequência não encontrada'});
    res.json(r.rows[0]);
  } catch(e){ res.status(500).json({message:'Erro ao buscar frequência', details:e.message}); }
};
exports.freqCriar = async (req,res)=>{
  try{
    const { matricula_turma_id, data_aula, presente, justificativa } = req.body;
    const r = await pool.query(`INSERT INTO frequencias (matricula_turma_id, data_aula, presente, justificativa)
      VALUES ($1,$2,$3,$4) RETURNING *`, [matricula_turma_id, data_aula, presente, justificativa||null]);
    res.status(201).json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao lançar frequência', details:e.message}); }
};
exports.freqAtualizar = async (req,res)=>{
  try{
    const fields=['matricula_turma_id','data_aula','presente','justificativa'];
    const set=[], vals=[];
    fields.forEach(f=>{ if(f in req.body){ vals.push(req.body[f]); set.push(`${f}=$${vals.length}`);} });
    if(!set.length) return res.status(400).json({message:'Nenhum campo para atualizar'});
    vals.push(req.params.id);
    const r = await pool.query(`UPDATE frequencias SET ${set.join(', ')} WHERE id_frequencia=$${vals.length} RETURNING *`, vals);
    if(!r.rowCount) return res.status(404).json({message:'Frequência não encontrada'});
    res.json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao atualizar frequência', details:e.message}); }
};
exports.freqDeletar = async (req,res)=>{
  try{
    const r = await pool.query('DELETE FROM frequencias WHERE id_frequencia=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Frequência não encontrada'});
    res.status(204).send();
  } catch(e){ res.status(400).json({message:'Erro ao deletar frequência', details:e.message}); }
};

// Histórico
exports.histListar = async (req,res)=>{
  try{
    const { aluno_id, turma_id, situacao_final } = req.query;
    const p=[], w=[];
    if(aluno_id){ p.push(aluno_id); w.push(`aluno_id=$${p.length}`); }
    if(turma_id){ p.push(turma_id); w.push(`turma_id=$${p.length}`); }
    if(situacao_final){ p.push(situacao_final); w.push(`situacao_final=$${p.length}`); }
    const r = await pool.query(`SELECT * FROM historico ${w.length?'WHERE '+w.join(' AND '):''} ORDER BY id_historico DESC`, p);
    res.json(r.rows);
  } catch(e){ res.status(500).json({message:'Erro ao listar histórico', details:e.message}); }
};
exports.histBuscar = async (req,res)=>{
  try{
    const r = await pool.query('SELECT * FROM historico WHERE id_historico=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Histórico não encontrado'});
    res.json(r.rows[0]);
  } catch(e){ res.status(500).json({message:'Erro ao buscar histórico', details:e.message}); }
};
exports.histCriar = async (req,res)=>{
  try{
    const { aluno_id, turma_id, nota_final, frequencia_percentual, situacao_final, data_conclusao } = req.body;
    const r = await pool.query(`
      INSERT INTO historico (aluno_id, turma_id, nota_final, frequencia_percentual, situacao_final, data_conclusao)
      VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [aluno_id, turma_id, nota_final||null, frequencia_percentual||null, situacao_final, data_conclusao||null]);
    res.status(201).json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao lançar histórico', details:e.message}); }
};
exports.histAtualizar = async (req,res)=>{
  try{
    const fields=['aluno_id','turma_id','nota_final','frequencia_percentual','situacao_final','data_conclusao'];
    const set=[], vals=[];
    fields.forEach(f=>{ if(f in req.body){ vals.push(req.body[f]); set.push(`${f}=$${vals.length}`);} });
    if(!set.length) return res.status(400).json({message:'Nenhum campo para atualizar'});
    vals.push(req.params.id);
    const r = await pool.query(`UPDATE historico SET ${set.join(', ')} WHERE id_historico=$${vals.length} RETURNING *`, vals);
    if(!r.rowCount) return res.status(404).json({message:'Histórico não encontrado'});
    res.json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao atualizar histórico', details:e.message}); }
};
exports.histDeletar = async (req,res)=>{
  try{
    const r = await pool.query('DELETE FROM historico WHERE id_historico=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Histórico não encontrado'});
    res.status(204).send();
  } catch(e){ res.status(400).json({message:'Erro ao deletar histórico', details:e.message}); }
};

// Plano de ensino
exports.planoListar = async (req,res)=>{
  try{
    const { turma_id } = req.query;
    const p=[], w=[];
    if(turma_id){ p.push(turma_id); w.push(`turma_id=$${p.length}`); }
    const r = await pool.query(`SELECT * FROM planos_ensino ${w.length?'WHERE '+w.join(' AND '):''} ORDER BY id_plano DESC`, p);
    res.json(r.rows);
  } catch(e){ res.status(500).json({message:'Erro ao listar planos', details:e.message}); }
};
exports.planoBuscar = async (req,res)=>{
  try{
    const r = await pool.query('SELECT * FROM planos_ensino WHERE id_plano=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Plano não encontrado'});
    res.json(r.rows[0]);
  } catch(e){ res.status(500).json({message:'Erro ao buscar plano', details:e.message}); }
};
exports.planoCriar = async (req,res)=>{
  try{
    const { turma_id, objetivos, conteudo_programatico, metodologia, criterios_avaliacao, bibliografia_basica, bibliografia_complementar, aprovado } = req.body;
    const r = await pool.query(`
      INSERT INTO planos_ensino (turma_id, objetivos, conteudo_programatico, metodologia, criterios_avaliacao, bibliografia_basica, bibliografia_complementar, aprovado)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [turma_id, objetivos, conteudo_programatico, metodologia, criterios_avaliacao, bibliografia_basica, bibliografia_complementar||null, aprovado||false]);
    res.status(201).json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao cadastrar plano', details:e.message}); }
};
exports.planoAtualizar = async (req,res)=>{
  try{
    const fields=['turma_id','objetivos','conteudo_programatico','metodologia','criterios_avaliacao','bibliografia_basica','bibliografia_complementar','aprovado'];
    const set=[], vals=[];
    fields.forEach(f=>{ if(f in req.body){ vals.push(req.body[f]); set.push(`${f}=$${vals.length}`);} });
    if(!set.length) return res.status(400).json({message:'Nenhum campo para atualizar'});
    vals.push(req.params.id);
    const r = await pool.query(`UPDATE planos_ensino SET ${set.join(', ')} WHERE id_plano=$${vals.length} RETURNING *`, vals);
    if(!r.rowCount) return res.status(404).json({message:'Plano não encontrado'});
    res.json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao atualizar plano', details:e.message}); }
};
exports.planoDeletar = async (req,res)=>{
  try{
    const r = await pool.query('DELETE FROM planos_ensino WHERE id_plano=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Plano não encontrado'});
    res.status(204).send();
  } catch(e){ res.status(400).json({message:'Erro ao deletar plano', details:e.message}); }
};

// Atividades complementares
exports.ativListar = async (req,res)=>{
  try{
    const { aluno_id, status_validacao } = req.query;
    const p=[], w=[];
    if(aluno_id){ p.push(aluno_id); w.push(`aluno_id=$${p.length}`); }
    if(status_validacao){ p.push(status_validacao); w.push(`status_validacao=$${p.length}`); }
    const r = await pool.query(`SELECT * FROM atividades_complementares ${w.length?'WHERE '+w.join(' AND '):''} ORDER BY id_atividade DESC`, p);
    res.json(r.rows);
  } catch(e){ res.status(500).json({message:'Erro ao listar atividades', details:e.message}); }
};
exports.ativBuscar = async (req,res)=>{
  try{
    const r = await pool.query('SELECT * FROM atividades_complementares WHERE id_atividade=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Atividade não encontrada'});
    res.json(r.rows[0]);
  } catch(e){ res.status(500).json({message:'Erro ao buscar atividade', details:e.message}); }
};
exports.ativCriar = async (req,res)=>{
  try{
    const { aluno_id, tipo_atividade, descricao, carga_horaria, data_realizacao } = req.body;
    const r = await pool.query(`
      INSERT INTO atividades_complementares (aluno_id, tipo_atividade, descricao, carga_horaria, data_realizacao)
      VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [aluno_id, tipo_atividade, descricao, carga_horaria, data_realizacao]);
    res.status(201).json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao cadastrar atividade', details:e.message}); }
};
exports.ativAtualizar = async (req,res)=>{
  try{
    const fields=['aluno_id','tipo_atividade','descricao','carga_horaria','data_realizacao','status_validacao','validador_id','data_validacao','observacao'];
    const set=[], vals=[];
    fields.forEach(f=>{ if(f in req.body){ vals.push(req.body[f]); set.push(`${f}=$${vals.length}`);} });
    if(!set.length) return res.status(400).json({message:'Nenhum campo para atualizar'});
    vals.push(req.params.id);
    const r = await pool.query(`UPDATE atividades_complementares SET ${set.join(', ')} WHERE id_atividade=$${vals.length} RETURNING *`, vals);
    if(!r.rowCount) return res.status(404).json({message:'Atividade não encontrada'});
    res.json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao atualizar atividade', details:e.message}); }
};
exports.ativDeletar = async (req,res)=>{
  try{
    const r = await pool.query('DELETE FROM atividades_complementares WHERE id_atividade=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Atividade não encontrada'});
    res.status(204).send();
  } catch(e){ res.status(400).json({message:'Erro ao deletar atividade', details:e.message}); }
};

// TCC
exports.tccListar = async (req,res)=>{
  try{
    const { aluno_id, curso_id, status } = req.query;
    const p=[], w=[];
    if(aluno_id){ p.push(aluno_id); w.push(`aluno_id=$${p.length}`); }
    if(curso_id){ p.push(curso_id); w.push(`curso_id=$${p.length}`); }
    if(status){ p.push(status); w.push(`status=$${p.length}`); }
    const r = await pool.query(`SELECT * FROM tcc ${w.length?'WHERE '+w.join(' AND '):''} ORDER BY id_tcc DESC`, p);
    res.json(r.rows);
  } catch(e){ res.status(500).json({message:'Erro ao listar TCC', details:e.message}); }
};
exports.tccBuscar = async (req,res)=>{
  try{
    const r = await pool.query('SELECT * FROM tcc WHERE id_tcc=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'TCC não encontrado'});
    res.json(r.rows[0]);
  } catch(e){ res.status(500).json({message:'Erro ao buscar TCC', details:e.message}); }
};
exports.tccCriar = async (req,res)=>{
  try{
    const { aluno_id, curso_id, titulo, orientador_id, coorientador_id, data_inicio, data_defesa, nota_final, status, arquivo_url } = req.body;
    const r = await pool.query(`
      INSERT INTO tcc (aluno_id, curso_id, titulo, orientador_id, coorientador_id, data_inicio, data_defesa, nota_final, status, arquivo_url)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
      [aluno_id, curso_id, titulo, orientador_id, coorientador_id||null, data_inicio, data_defesa||null, nota_final||null, status, arquivo_url||null]);
    res.status(201).json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao cadastrar TCC', details:e.message}); }
};
exports.tccAtualizar = async (req,res)=>{
  try{
    const fields=['aluno_id','curso_id','titulo','orientador_id','coorientador_id','data_inicio','data_defesa','nota_final','status','arquivo_url'];
    const set=[], vals=[];
    fields.forEach(f=>{ if(f in req.body){ vals.push(req.body[f]); set.push(`${f}=$${vals.length}`);} });
    if(!set.length) return res.status(400).json({message:'Nenhum campo para atualizar'});
    vals.push(req.params.id);
    const r = await pool.query(`UPDATE tcc SET ${set.join(', ')} WHERE id_tcc=$${vals.length} RETURNING *`, vals);
    if(!r.rowCount) return res.status(404).json({message:'TCC não encontrado'});
    res.json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao atualizar TCC', details:e.message}); }
};
exports.tccDeletar = async (req,res)=>{
  try{
    const r = await pool.query('DELETE FROM tcc WHERE id_tcc=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'TCC não encontrado'});
    res.status(204).send();
  } catch(e){ res.status(400).json({message:'Erro ao deletar TCC', details:e.message}); }
};

// Mensagens
exports.msgListar = async (req,res)=>{
  try{
    const { remetente_id, tipo_remetente, destinatario_id, tipo_destinatario, status, prioridade } = req.query;
    const p=[], w=[];
    if(remetente_id){ p.push(remetente_id); w.push(`remetente_id=$${p.length}`); }
    if(tipo_remetente){ p.push(tipo_remetente); w.push(`tipo_remetente=$${p.length}`); }
    if(destinatario_id){ p.push(destinatario_id); w.push(`destinatario_id=$${p.length}`); }
    if(tipo_destinatario){ p.push(tipo_destinatario); w.push(`tipo_destinatario=$${p.length}`); }
    if(status){ p.push(status); w.push(`status=$${p.length}`); }
    if(prioridade){ p.push(prioridade); w.push(`prioridade=$${p.length}`); }
    const r = await pool.query(`SELECT * FROM mensagens ${w.length?'WHERE '+w.join(' AND '):''} ORDER BY id_mensagem DESC`, p);
    res.json(r.rows);
  } catch(e){ res.status(500).json({message:'Erro ao listar mensagens', details:e.message}); }
};
exports.msgBuscar = async (req,res)=>{
  try{
    const r = await pool.query('SELECT * FROM mensagens WHERE id_mensagem=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Mensagem não encontrada'});
    res.json(r.rows[0]);
  } catch(e){ res.status(500).json({message:'Erro ao buscar mensagem', details:e.message}); }
};
exports.msgCriar = async (req,res)=>{
  try{
    const { remetente_id, tipo_remetente, destinatario_id, tipo_destinatario, titulo, conteudo, prioridade, categoria, anexo_url, mensagem_pai_id, status } = req.body;
    const r = await pool.query(`
      INSERT INTO mensagens (remetente_id, tipo_remetente, destinatario_id, tipo_destinatario, titulo, conteudo, prioridade, categoria, anexo_url, mensagem_pai_id, status)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
      [remetente_id, tipo_remetente, destinatario_id, tipo_destinatario, titulo, conteudo, prioridade||null, categoria||null, anexo_url||null, mensagem_pai_id||null, status||'enviada']);
    res.status(201).json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao enviar mensagem', details:e.message}); }
};
exports.msgAtualizar = async (req,res)=>{
  try{
    const fields=['remetente_id','tipo_remetente','destinatario_id','tipo_destinatario','titulo','conteudo','prioridade','categoria','anexo_url','mensagem_pai_id','status','lida','data_leitura'];
    const set=[], vals=[];
    fields.forEach(f=>{ if(f in req.body){ vals.push(req.body[f]); set.push(`${f}=$${vals.length}`);} });
    if(!set.length) return res.status(400).json({message:'Nenhum campo para atualizar'});
    vals.push(req.params.id);
    const r = await pool.query(`UPDATE mensagens SET ${set.join(', ')} WHERE id_mensagem=$${vals.length} RETURNING *`, vals);
    if(!r.rowCount) return res.status(404).json({message:'Mensagem não encontrada'});
    res.json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao atualizar mensagem', details:e.message}); }
};
exports.msgDeletar = async (req,res)=>{
  try{
    const r = await pool.query('DELETE FROM mensagens WHERE id_mensagem=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Mensagem não encontrada'});
    res.status(204).send();
  } catch(e){ res.status(400).json({message:'Erro ao deletar mensagem', details:e.message}); }
};

// Mensagens em grupo
exports.msggListar = async (req,res)=>{
  try{
    const { mensagem_id, destinatario_id, tipo_destinatario, lida } = req.query;
    const p=[], w=[];
    if(mensagem_id){ p.push(mensagem_id); w.push(`mensagem_id=$${p.length}`); }
    if(destinatario_id){ p.push(destinatario_id); w.push(`destinatario_id=$${p.length}`); }
    if(tipo_destinatario){ p.push(tipo_destinatario); w.push(`tipo_destinatario=$${p.length}`); }
    if(typeof lida !== 'undefined'){ p.push(lida==='true'); w.push(`lida=$${p.length}`); }
    const r = await pool.query(`SELECT * FROM mensagens_grupo ${w.length?'WHERE '+w.join(' AND '):''} ORDER BY id_mensagem_grupo DESC`, p);
    res.json(r.rows);
  } catch(e){ res.status(500).json({message:'Erro ao listar mensagens de grupo', details:e.message}); }
};
exports.msggBuscar = async (req,res)=>{
  try{
    const r = await pool.query('SELECT * FROM mensagens_grupo WHERE id_mensagem_grupo=$1',[req.params.id]);
    if(!r.rowCount) return res.status(404).json({message:'Mensagem de grupo não encontrada'});
    res.json(r.rows[0]);
  } catch(e){ res.status(500).json({message:'Erro ao buscar mensagem de grupo', details:e.message}); }
};
exports.msggCriar = async (req,res)=>{
  try{
    const { mensagem_id, destinatario_id, tipo_destinatario } = req.body;
    const r = await pool.query(`
      INSERT INTO mensagens_grupo (mensagem_id, destinatario_id, tipo_destinatario)
      VALUES ($1,$2,$3) RETURNING *`, [mensagem_id, destinatario_id, tipo_destinatario]);
    res.status(201).json(r.rows[0]);
  } catch(e){ res.status(400).json({message:'Erro ao cadastrar mensagem de grupo', details:e.message}); }
};
exports
